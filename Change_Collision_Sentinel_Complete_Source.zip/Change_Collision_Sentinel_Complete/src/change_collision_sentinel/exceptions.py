class SentinelError(Exception):
    """Base exception for safe, user-visible prototype errors."""
class ValidationError(SentinelError): pass
class DataError(SentinelError): pass
