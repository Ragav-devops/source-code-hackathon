from __future__ import annotations
from dataclasses import dataclass, field, asdict
from datetime import datetime
from typing import Any

@dataclass(frozen=True)
class ChangeRequest:
    change_id:str; change_type:str; title:str; services:list[str]; components:list[str]; location:str; window:str; risk:str; status:str; actions_remove:list[str]; actions_require:list[str]; rollback_requires:list[str]; validation:str; owner_team:str
    def to_dict(self)->dict[str,Any]: return asdict(self)

@dataclass(frozen=True)
class DependencyEdge:
    source:str; target:str; relationship:str

@dataclass
class CollisionFinding:
    left_change:str; right_change:str; reasons:list[str]=field(default_factory=list); shared:list[str]=field(default_factory=list); action_conflicts:list[str]=field(default_factory=list); rollback_conflicts:list[str]=field(default_factory=list); score:int=0; severity:str="NONE"
    def to_dict(self)->dict[str,Any]: return asdict(self)
