from pathlib import Path
import json, random
def write_copy(source:Path,target:Path,seed:int=42)->None:
    random.seed(seed); rows=json.loads(source.read_text()); random.shuffle(rows); target.write_text(json.dumps(rows,indent=2))
