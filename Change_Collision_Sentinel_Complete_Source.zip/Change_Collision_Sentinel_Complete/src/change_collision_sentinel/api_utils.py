from __future__ import annotations
import json
def ok(data:dict)->dict: return {"status":"ok","data":data}
def error(exc:Exception)->dict: return {"status":"error","error_type":type(exc).__name__,"message":str(exc)}
def pretty(data:dict)->str: return json.dumps(data,indent=2,sort_keys=True)
