from __future__ import annotations
import logging
from typing import Any
from .exceptions import ValidationError
from .repository import load_changes
from .engine import find_collisions, overlaps
from .recommender import classify_impact, rollback_issues, coordination_plan
LOG=logging.getLogger("change_collision_sentinel")

def _select(ids:list[str]):
    if not ids: raise ValidationError("At least one change ID is required")
    all_changes={c.change_id:c for c in load_changes()}; missing=[i for i in ids if i not in all_changes]
    if missing: raise ValidationError(f"Unknown change IDs: {missing}")
    return [all_changes[i] for i in dict.fromkeys(ids)]

def ingest_change_requests(change_ids:list[str])->dict[str,Any]:
    """Retrieve validated planned changes from the local prototype dataset. Args: change_ids: exact IDs. Returns: records and count. Example: ingest_change_requests(["CHG-1042"])."""
    rows=_select(change_ids); LOG.info("ingested ids=%s",change_ids); return {"count":len(rows),"changes":[c.to_dict() for c in rows]}

def dependency_graph_builder(change_ids:list[str])->dict[str,Any]:
    """Build a change-to-service-to-component dependency graph. Args: change_ids. Returns: nodes and edges. Example: dependency_graph_builder(["CHG-1042","CHG-1051"])."""
    rows=_select(change_ids); nodes=set(); edges=[]
    for c in rows:
        nodes.add(c.change_id)
        for s in c.services: nodes.add(s); edges.append({"source":c.change_id,"target":s,"relationship":"affects"})
        for comp in c.components: nodes.add(comp); edges.append({"source":c.change_id,"target":comp,"relationship":"touches"})
    LOG.info("graph nodes=%d edges=%d",len(nodes),len(edges)); return {"nodes":sorted(nodes),"edges":edges}

def maintenance_window_analyzer(change_ids:list[str])->dict[str,Any]:
    """Identify overlapping maintenance windows. Args: two or more change IDs. Returns: overlap pairs. Example: maintenance_window_analyzer(["CHG-1042","CHG-1051"])."""
    rows=_select(change_ids); pairs=[]
    for i,left in enumerate(rows):
        for right in rows[i+1:]:
            if overlaps(left.window,right.window): pairs.append({"changes":[left.change_id,right.change_id],"overlap":True})
    return {"overlap_count":len(pairs),"pairs":pairs}

def collision_detector(change_ids:list[str])->dict[str,Any]:
    """Detect interaction risk across approved changes. Args: two or more IDs. Returns: evidence-rich collision findings. Example: collision_detector(["CHG-1042","CHG-1051","CHG-1060"])."""
    rows=_select(change_ids)
    if len(rows)<2: raise ValidationError("Collision analysis needs at least two unique changes")
    findings=find_collisions(rows); LOG.warning("collisions=%d ids=%s",len(findings),change_ids); return {"collision_detected":bool(findings),"findings":[f.to_dict() for f in findings]}

def impact_classifier(change_ids:list[str])->dict[str,Any]:
    """Classify combined impact from deterministic collision evidence. Args: change IDs. Returns: score, severity and review flag."""
    rows=_select(change_ids); return classify_impact(find_collisions(rows))

def rollback_validator(change_ids:list[str])->dict[str,Any]:
    """Validate whether one change removes another change's rollback path. Args: change IDs. Returns: issues and validity."""
    rows=_select(change_ids); issues=rollback_issues(rows,find_collisions(rows)); return {"rollback_valid":not issues,"issues":issues}

def cab_recommendation_generator(change_ids:list[str])->dict[str,Any]:
    """Generate a human-reviewable CAB sequence, hold points and rollback order. This tool never approves or executes changes."""
    rows=_select(change_ids); return coordination_plan(rows,find_collisions(rows))

def executive_summary_generator(change_ids:list[str])->dict[str,Any]:
    """Create an executive CAB summary from deterministic collision evidence and recommendation data."""
    rows=_select(change_ids); findings=find_collisions(rows); impact=classify_impact(findings); plan=coordination_plan(rows,findings)
    return {"title":"Change Collision Sentinel CAB Briefing","changes_reviewed":change_ids,"impact":impact,"key_evidence":[r for f in findings for r in f.reasons],"decision":plan["gate"],"recommended_order":[x["change_id"] for x in plan["execution"]],"rollback_order":plan["rollback_order"],"human_approval_required":True,"disclaimer":plan["disclaimer"]}
