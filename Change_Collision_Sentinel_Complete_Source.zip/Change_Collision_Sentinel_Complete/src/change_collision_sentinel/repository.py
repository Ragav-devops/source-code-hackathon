from __future__ import annotations
import json
from dataclasses import fields
from pathlib import Path
from .exceptions import DataError, ValidationError
from .models import ChangeRequest
ROOT=Path(__file__).resolve().parents[2]

def load_json(path:Path):
    if not path.exists(): raise DataError(f"Missing data file: {path}")
    try: return json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc: raise DataError(f"Invalid JSON in {path}: {exc}") from exc

def load_changes(path:Path|None=None)->list[ChangeRequest]:
    rows=load_json(path or ROOT/"data/changes.json")
    required={f.name for f in fields(ChangeRequest)}
    result=[]
    for index,row in enumerate(rows):
        missing=required-set(row)
        if missing: raise ValidationError(f"Record {index} missing: {sorted(missing)}")
        result.append(ChangeRequest(**{k:row[k] for k in required}))
    return result

def load_policies(path:Path|None=None): return load_json(path or ROOT/"config/policies.json")["rules"]
