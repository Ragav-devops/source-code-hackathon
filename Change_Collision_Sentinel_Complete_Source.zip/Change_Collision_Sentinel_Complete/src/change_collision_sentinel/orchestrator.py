from __future__ import annotations
from .tools import ingest_change_requests,dependency_graph_builder,maintenance_window_analyzer,collision_detector,impact_classifier,rollback_validator,cab_recommendation_generator,executive_summary_generator
def run_workflow(change_ids:list[str])->dict:
    return {"ingest":ingest_change_requests(change_ids),"graph":dependency_graph_builder(change_ids),"windows":maintenance_window_analyzer(change_ids),"collisions":collision_detector(change_ids),"impact":impact_classifier(change_ids),"rollback":rollback_validator(change_ids),"cab":cab_recommendation_generator(change_ids),"summary":executive_summary_generator(change_ids)}
