from __future__ import annotations
from .models import ChangeRequest, CollisionFinding

def classify_impact(findings:list[CollisionFinding])->dict:
    score=max((f.score for f in findings),default=0); sev=max((f.severity for f in findings),key=lambda x:{"NONE":0,"LOW":1,"MEDIUM":2,"HIGH":3,"CRITICAL":4}[x],default="NONE")
    return {"overall_score":score,"overall_severity":sev,"collision_count":len(findings),"human_review_required":bool(findings)}

def rollback_issues(changes:list[ChangeRequest],findings:list[CollisionFinding])->list[dict]:
    return [{"changes":[f.left_change,f.right_change],"missing_or_removed":f.rollback_conflicts} for f in findings if f.rollback_conflicts]

def coordination_plan(changes:list[ChangeRequest],findings:list[CollisionFinding])->dict:
    ordered=sorted(changes,key=lambda c:(len(c.actions_remove),c.change_id))
    scale={"NONE":0,"LOW":1,"MEDIUM":2,"HIGH":3,"CRITICAL":4}; highest=max((f.severity for f in findings),key=lambda x:scale[x],default="NONE")
    gate="BLOCK_CONCURRENT_EXECUTION" if highest in {"HIGH","CRITICAL"} else "JOINT_CAB_REVIEW" if findings else "STANDARD_REVIEW"
    return {"gate":gate,"execution":[{"step":i+1,"change_id":c.change_id,"title":c.title,"validation":c.validation,"hold_point":True} for i,c in enumerate(ordered)],"rollback_order":[c.change_id for c in reversed(ordered)],"approvals":["Joint CAB","Service Owner"] if findings else ["Standard CAB"],"disclaimer":"Decision support only; no change is approved or executed."}
