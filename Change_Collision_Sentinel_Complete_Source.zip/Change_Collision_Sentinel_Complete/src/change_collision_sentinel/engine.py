from __future__ import annotations
from datetime import datetime
from itertools import combinations
from .exceptions import ValidationError
from .models import ChangeRequest, CollisionFinding

def parse_window(value:str):
    try:
        a,b=value.split("/"); start=datetime.fromisoformat(a.replace("Z","+00:00")); end=datetime.fromisoformat(b.replace("Z","+00:00"))
    except Exception as exc: raise ValidationError(f"Invalid ISO window: {value}") from exc
    if end<=start: raise ValidationError("Window end must be after start")
    return start,end

def overlaps(a:str,b:str)->bool:
    a1,a2=parse_window(a); b1,b2=parse_window(b); return a1<b2 and b1<a2

def severity(score:int)->str:
    return "CRITICAL" if score>=80 else "HIGH" if score>=50 else "MEDIUM" if score>=25 else "LOW" if score>0 else "NONE"

def find_collisions(changes:list[ChangeRequest])->list[CollisionFinding]:
    findings=[]
    for left,right in combinations(changes,2):
        if not overlaps(left.window,right.window): continue
        shared=sorted(set(left.components)&set(right.components))
        actions=sorted((set(left.actions_remove)&set(right.actions_require))|(set(right.actions_remove)&set(left.actions_require)))
        rollback=sorted((set(left.actions_remove)&set(right.rollback_requires))|(set(right.actions_remove)&set(left.rollback_requires)))
        same_service=bool(set(left.services)&set(right.services)); same_location=left.location==right.location
        score=min(100,25*bool(shared)+50*bool(actions)+60*bool(rollback)+15*same_service+10*same_location)
        if not score: continue
        reasons=["maintenance windows overlap"]
        if shared: reasons.append("shared components: "+", ".join(shared))
        if actions: reasons.append("required dependency removed: "+", ".join(actions))
        if rollback: reasons.append("rollback dependency removed: "+", ".join(rollback))
        if same_service: reasons.append("same business service")
        if same_location: reasons.append("same location")
        findings.append(CollisionFinding(left.change_id,right.change_id,reasons,shared,actions,rollback,score,severity(score)))
    return findings
