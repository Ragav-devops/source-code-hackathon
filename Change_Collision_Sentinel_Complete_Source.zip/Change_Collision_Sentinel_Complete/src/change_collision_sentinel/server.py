from __future__ import annotations
import logging
from fastmcp import FastMCP
from .tools import *
logging.basicConfig(level=logging.INFO,format="%(asctime)s %(levelname)s %(name)s %(message)s")
mcp=FastMCP(name="Change Collision Sentinel",instructions="Detect hidden collisions across planned changes. Use deterministic tools. Never approve, schedule or execute changes. Require human CAB review.")
for tool in [ingest_change_requests,dependency_graph_builder,maintenance_window_analyzer,collision_detector,impact_classifier,rollback_validator,cab_recommendation_generator,executive_summary_generator]: mcp.tool(tool)
if __name__=="__main__": mcp.run(transport="sse",host="0.0.0.0",port=8090)
