import unittest
from change_collision_sentinel.orchestrator import run_workflow
class Integration(unittest.TestCase):
 def test_workflow(self):
  result=run_workflow(["CHG-1042","CHG-1051","CHG-1060"]); self.assertEqual(result["summary"]["decision"],"BLOCK_CONCURRENT_EXECUTION")
