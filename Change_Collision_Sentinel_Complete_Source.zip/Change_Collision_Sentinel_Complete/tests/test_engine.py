import unittest
from change_collision_sentinel.tools import collision_detector,rollback_validator,executive_summary_generator
from change_collision_sentinel.exceptions import ValidationError
class Tests(unittest.TestCase):
 def test_primary(self): self.assertTrue(collision_detector(["CHG-1042","CHG-1051"])["collision_detected"])
 def test_rollback(self): self.assertFalse(rollback_validator(["CHG-1042","CHG-1051"])["rollback_valid"])
 def test_safe(self): self.assertFalse(collision_detector(["CHG-1042","CHG-1077"])["collision_detected"])
 def test_unknown(self):
  with self.assertRaises(ValidationError): collision_detector(["CHG-9999","CHG-1042"])
 def test_summary(self): self.assertTrue(executive_summary_generator(["CHG-1042","CHG-1051"])["human_approval_required"])
