# Change Collision Sentinel

KAF-compatible multi-tool MCP hackathon prototype.

## Run
```bash
uv sync
PYTHONPATH=src uv run python -m change_collision_sentinel.server
```
Endpoint: `http://localhost:8090/sse`

## Test
```bash
PYTHONPATH=src python -m unittest discover -s tests -v
npx @modelcontextprotocol/inspector http://localhost:8090/sse
```

## Docker
```bash
docker compose up --build
```

## KAF safety
Decision support only. Human CAB approval is mandatory.
